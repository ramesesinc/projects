package water.actions;

import com.rameses.rules.common.*;
import bpls.facts.*;
import java.rmi.server.*;

public class ComputeFee implements RuleActionHandler {
	def request;
	def BA;
	def NA;
	def type;
	public void execute(def params, def drools) {
		def entity = request.entity;
		def fees = request.fees;
		def feefacts = request.feefacts;
		
		def acctid = params.account.key;
		def amt = params.amount.doubleValue;
		
		def test = fees.find{ it.account.objid == acctid };

		//if account already exists, do not override.
		if(!test) {
			def info = [objid:"WTRFEE"+new UID()];
			info.account = BA.findAccount( [objid: acctid] );
			info.amount = NA.round(amt);
			info.rulename = drools.rule.name;
			fees << info;
			feefacts << info;
		}
		else {
			//add rule history so we can trace rules that executed the account.
			if( test._fees == null ) test._fees = [];
			def hist = [rulename: drools.rule.name, amount: amt];
			test._fees << hist;
		}
	}
}