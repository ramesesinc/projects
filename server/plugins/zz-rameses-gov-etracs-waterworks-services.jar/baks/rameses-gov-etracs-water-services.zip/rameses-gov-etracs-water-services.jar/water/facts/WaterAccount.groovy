package water.facts;

class WaterAccount {

    String classType;
    int consumption;	

}